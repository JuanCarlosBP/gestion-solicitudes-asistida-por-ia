# AG-012 — Solicitudes, conceptos, importes y presentación

**Estado:** 004 verificada localmente; continuación AG-012 en curso. Sin aceptación ni integración.
**Autorización:** orden humana integral AG-012, D004-01–11 y continuación005 condicionada.
**Inicio:** 2026-10-14T23:34:02+02:00; **límite:** 2026-10-15T09:34:02+02:00.
**Zona:** Europe/Madrid. Cierre y duración se registrarán al terminar.
Rama comunicada: feature/004-solicitudes-conceptos-importes; no comprobada con Git.

## Alcance y preservación

Obligatorio004, continuación005 solo tras verificación completa y margen120min;
006 solo borrador después de005 verificada con45min. Ninguna operación Git,
integración de PR ni publicación. Históricos AG003–AG011, REV001, ADR0001–0004,
validaciones anteriores y prefijo CSV preservados mediante huellas/bytes iniciales.
Fuentes iniciales en qa/evidencias/ag012/huellas-entrada.json; no acreditan hechos
anteriores a su captura. Evidencias nuevas AG012 y temporales dentro del workspace.

## Precondición y defecto heredado

Java21.0.12.1, Node24.13.0, npm11.6.2 y Docker29.1.3 comprobados. Compile backend
y build Angular heredados PASS a23:35:28;1.43min desde inicio, dentro de20min.
Compose arrancado con infraestructura/.env.example y volumen ficticio heredado.
No se repitió toda AG011 antes de programar; la regresión adicional es la
exigida expresamente para el fallo heredado.

Consulta GitHub de solo lectura: PR3 abierta/borrador; run38633782500,
head cfc8db3fd8b019b46b41cf23edfb09898989e16e. Backend/frontend PASS remotos;
Compose falla en paso10 E2E003, esperaba1/recibió2. Extracto original conservado.
Reproducción local: esperaba1/recibió6 con catálogo acumulado, campos de búsqueda
vacíos en captura. No se ha demostrado un defecto del buscador SQL.
Corrección01 solo de prueba: UUID, dato Unicode dentro de límites, esperar foco
y fin de carga, denominación completa única, fiscal exacto y aserción de URL.
Enfocada PASS1/1 y regresión E2E PASS9/9 sin reintentos; backend verify PASS98,
Spotless/SpotBugs; Angular PASS130 y tipos/lint/formato/build. Regresión completa
antes del desarrollo sustancial004. [Adenda003](../../especificaciones/003-proveedores/validacion-ag012.md).

Fallos de entorno preservados: acceso Docker/loopback restringido y resolución
Vite bajo sandbox. Ejecuciones autorizadas con acceso local resolvieron esas
limitaciones sin cambiar fuentes, dependencias ni controles.

## Orquestación y autorización documental

Roles personalizados invocados sin preparación adicional: planificador solo
lectura, implementador backend, implementador frontend y revisor solo lectura.
Máximo tres subagentes concurrentes; planificador termina antes de revisión.
El coordinador escribe spec/plan/tareas/ADR, QA/CI, documentación, índices y cierre.
Backend escribe backend; frontend escribe frontend/src y nuevo E2E004.
E2E003 reservado al coordinador. Ningún escritor puede sobrescribir otro.
Solo lectura de planificador/revisor por instrucción, sin aislamiento técnico
acreditado: permisos de sesión workspace-write y red restringida con auto-review.
Skills SDD, QA, documentación y revisión de seguridad aplicadas por lectura.

SDD004 y ADR0005 redactados con origen de aprobación humana AG-012 antes del código.
Contrato compartido cerrado: decimales texto, colección completa y versión,
resultado mínimo de presentación persistido, selector mínimo y filtros acotados.

## Implementación 004

La [especificación](../../especificaciones/004-solicitudes-conceptos-importes/especificacion.md),
el [plan](../../especificaciones/004-solicitudes-conceptos-importes/plan.md), las
[tareas](../../especificaciones/004-solicitudes-conceptos-importes/tareas.md) y
[ADR-0005](../decisiones/ADR-0005-solicitudes-importes-presentacion.md) incorporan
D-004-01–11 por aprobación humana anterior al código.

| Área de entrega | Cambio y comprobación |
|---|---|
| V4 | Secuencia segura, solicitudes, conceptos e idempotencia; FK, checks, índices y privilegios mínimos. Evolución V3→V4 con datos y base vacía comprobadas. |
| HTTP | POST/GET colección, GET/PUT detalle, POST presentar y GET supervisores; 14 rutas totales en OpenAPI. Entradas cerradas, errores estables y no-store. |
| Importes | BigDecimal y HALF_UP por línea; 1×10.0000=10.00, 2.500×4.1250=10.31 y 3×0.3350=1.01; suma21.32EUR. Límites y desbordamientos controlados; decimales JSON como texto. |
| Permisos | Solicitante escribe borradores propios; supervisor lee presentadas asignadas; auditor/administrador leen todas. Unión de permisos explícitos, CSRF y404 para recursos no visibles. |
| Referencias | Proveedor vivo en borrador, inactividad bloquea presentar; fotografía inmutable al presentar. Supervisor habilitado con rol, distinto del autor y asignación fija. |
| Atomicidad | Cabecera y colección se reemplazan juntas; rollback real conserva todo. Presentación guarda estado, fotografía, versión y resultado idempotente en un commit. |
| Versión/idempotencia | Versiones obsoletas409; misma clave compatible devuelve resultado original persistido; incompatible409. Dos claves no duplican la transición. Replay sobrevive reinicio. |
| Listado | Visibilidad antes de contar, filtros AND, texto literal con acentos significativos, orden cerrado y desempateUUID, página máxima100. |
| Backend | Módulo solicitudes separado en HTTP, aplicación, dominio y JDBC. Clock/UUID/SQL parametrizado; eventos mínimos sin cuerpos ni credenciales. |
| Angular | Cuatro rutas; lista, detalle y editor; cálculo exacto estimado separado del total confirmado; selectores paginados, recuperación409, confirmación y replay. |
| Sistema visual | Tokens compartidos, navegación, paneles, chips, tabla/tarjetas, acciones e importes destacados; foco, reduced-motion y tamaños360/768/1440. |

No hay borrado físico de solicitudes, aprobación en004, reasignación ni historial
funcional completo. La retención definitiva permanece en los incrementos previstos.

## Pruebas y revisión 004

La [validación004](../../especificaciones/004-solicitudes-conceptos-importes/validacion.md)
es la fuente del estado SCI-01–14. Evidencias nuevas en
[AG-012](../../qa/evidencias/ag012/).

| Verificación ejecutada | Resultado observado |
|---|---|
| Backend verify final02 |144 PASS:76 unitarias+68 integración PostgreSQL real;98 anteriores+46 nuevas. Spotless/SpotBugs PASS sin exclusiones nuevas. |
| Concurrencia |9 carreras sincronizadas mediante bloqueos reales;12 altas con números únicos. Se prueban guardado/presentación, claves iguales/distintas y cambios concurrentes de referencias/rol. |
| Rollback |Triggers fallidos en PostgreSQL desechable después de modificar agregado y antes de persistir idempotencia; no quedan efectos ni eventos de éxito. |
| API Compose |Solicitudes119, sesiones88 y proveedores78 controles PASS sobre backend final. |
| Angular |275 PASS:130 anteriores+145 nuevas; tipos, lint, formato y build sin advertencias. |
| Docker |Builds backend/frontend sin caché; IDs runtime relacionados con manifestlist de los logs, sin exponer configuración. |
| Compose |Stop/start conserva historialV1–V4; caída PostgreSQL503 real y recuperación200; navegador incluido. |
| E2E001–004 |11 PASS sin reintentos:9 anteriores, recorrido de13 pasos004 y posiciones no consecutivas. Swagger ejecuta salud real. |
| Auditorías |npm producción/completa0 vulnerabilidades; OSV Maven offline132 componentes sin hallazgos, volcado público fresco con hash. Transitivas preliminares controladas porADR0002. |
| CI local |Actionlint y sintaxis verificadores PASS; Actions porSHA, PostgreSQL real y evidencias porjob. No equivale a ejecución remota. |
| Documentación/secretos |Enlaces y patrones acotados revisados; control adicional de JWT/claves privadas en evidencias. Repetición de cierre pendiente. |

Primeros fallos conservados: compilación de imports/anotación OpenAPI, avisos
SpotBugs corregidos sin exclusiones, fixtures frontend, formato Prettier, catálogo
de rutas Swagger desactualizado y CSRF obsoleto en llamadas de prueba. Ningún
defecto supera dos correcciones fallidas. Las advertencias de color del runner no
afectan al resultado. No se eliminaron aserciones ni controles para obtener PASS.

El revisor independiente confirma fuentes y evidencias backend, permisos,
rollback, carreras y privacidad; comprueba25 huellas backend y38 frontend.
Hallazgos cerrados: restricción SQL de tipoNULL, aislamiento/negativo del selector,
posiciones no consecutivas y Enter en búsquedas. Revisó capturas lista/detalle en
tres tamaños, conflicto y error. R004-UI03 también cerrada: barra sticky ocultaba
foco duranteTab; reproducción real62 pasos/24 centros ocultos, primera corrección
62/0 y regresión11/11 PASS. La directiva mide altura real y desplaza sin animación.
La última imagen frontend9e1a1dd6… y backend18a9ac00… están relacionadas en
`imagenes004-final.json`; salud y navegador repetidos tras esta corrección PASS.
La conclusión independiente no deja hallazgos abiertos y reserva al coordinador
la consolidación documental, realizada antes de evaluar la puerta005.

## Preservación y archivos

Las496 huellas protegidas capturadas al iniciar coinciden. El inventario inicial
con rg omitió63 logs ignorados; se contrastaron con huellas históricas AG011,
cuyos archivos de referencia también coinciden con la captura inicial:63/63
idénticos. El verificador distingue esas referencias de una captura nueva y no
clasifica los logs históricos como archivos creados. Prefijo CSV36924 bytes
conservado. No se han eliminado archivos del inventario.

El [manifiesto](../../qa/evidencias/ag012/entrega-manifiesto.json) enumera archivos
y SHA-256; su versión final se genera al cierre. El
[manifiesto de commits](../../qa/evidencias/ag012/manifiesto-commits.json) propone
grupos separables: arreglo E2E heredado, SDD/ADR004, backend, frontend, QA/CI y
documentación/evidencias. Es una propuesta para la persona responsable; ningún
commit, staging, consulta de estado/diff, rama, push o integración se ejecuta aquí.

## Riesgos, límites y siguientes pasos

004 tiene SCI-01–14 verificados localmente, incluida documentación y revisión.
La puerta005 se registra con hora real tras los controles documentales finales;
requiere004 completa y al menos120 minutos de margen.
006 solo podrá ser borrador tras005 verificada y45 minutos restantes.

100000 solicitudes es previsión de volumen, no carga medida. La revisión visual
es acotada, no auditoríaWCAG completa; los controles no acreditan OWASP íntegro.
No se prueba operación pública/HTTPS productivo ni retención/borrado jurídico.
Idempotencia local no se purga automáticamente. Datos QA ficticios permanecen en
el volumen. MigracionesV1–V3 y evidencias anteriores no se modificaron; el ajuste
local deV4 candidata se documenta en entorno y no autoriza reparar producción.

CI remota de estos cambios, aceptación, Git e integración son actuaciones humanas
pendientes. Al cierre se detendrá Compose sin borrar volúmenes y se registrarán
hora, duración, SCI completos y estado real de005/006. No se declara aceptación
ni integración de ningún incremento.
