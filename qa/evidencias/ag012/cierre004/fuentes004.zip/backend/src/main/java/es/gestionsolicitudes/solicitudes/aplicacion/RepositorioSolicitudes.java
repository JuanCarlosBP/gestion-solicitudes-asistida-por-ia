package es.gestionsolicitudes.solicitudes.aplicacion;

import es.gestionsolicitudes.solicitudes.dominio.*;
import java.time.Instant;
import java.util.*;

public interface RepositorioSolicitudes {
    long siguienteNumero();

    void crear(UUID id, String numero, UUID autor, String asunto, Instant ahora);

    Optional<Solicitud> buscar(UUID id, boolean bloquear, boolean conceptos);

    void guardar(UUID id, long version, DatosBorrador datos, Instant ahora);

    Optional<Solicitud.Proveedor> proveedor(UUID id, boolean bloquear);

    boolean supervisor(UUID id, boolean bloquear);

    Pagina<Solicitud.Persona> supervisores(UUID actor, String nombre, int pagina, int tamano);

    Pagina<Solicitud> listar(ActorSolicitud actor, ConsultaSolicitudes consulta);

    void bloquearClave(UUID usuario, UUID clave);

    record Operacion(String huella, ResultadoPresentacion resultado) {}

    Optional<Operacion> operacion(UUID usuario, UUID clave);

    void presentar(Solicitud solicitud, Solicitud.Proveedor proveedor, Instant ahora);

    void registrar(UUID usuario, UUID clave, String huella, ResultadoPresentacion resultado);
}
